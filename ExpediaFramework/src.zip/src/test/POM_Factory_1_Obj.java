package test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import PageFactory.Factory_1_Obj;
 
public class POM_Factory_1_Obj {
       public WebDriver driver;
        public String baseUrl;
        public Factory_1_Obj objFactory;
        @BeforeMethod
		public void setUp() throws Exception {
                driver = new FirefoxDriver();
                baseUrl = "https://www.expedia.com/";
               
                // Maximize the browser's window
                driver.manage().window().maximize();
                driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
                
        }
 
        @Test
        public void test() throws InterruptedException {
            driver.get(baseUrl);
            objFactory = new Factory_1_Obj(driver);
  
            objFactory.clickFlightsTab(); 
            //      driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);

                  objFactory.setOriginCity("Kitchener");
            //      Thread.sleep(500);
                
                  objFactory.setDestinationCity( "London");
                  
                  objFactory.setDepartureDate("01/11/2019");
                  
                  objFactory.setReturnDate("02/22/2019");
                  Thread.sleep(500);
                  objFactory.clickSearchButton();
                  
        }
       
        @AfterMethod
		public void tearDown() throws Exception {
        	driver.quit();
        }
 
}
 